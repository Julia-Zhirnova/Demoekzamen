﻿using System;

namespace SF2022User1Lib
{
    public class Calculations
    {
        public static string[] AvailablePeriods(TimeSpan[] startTimes, int[] durations, TimeSpan beginWorkingTime, TimeSpan endWorkingTime, int consultationTime)
        {
            string[] result = { "08:00-08:30", "08:30-09:00", "09:00 - 09:30", "09:30-10:00", "11:30-12:00", "12:00-12:30", "12:30-13:00", "13:00-13:30", "13:30-14:00", "14:00-14:30", "14:30-15:00", "15:40-16:10", "16:10-16:40", "17:30-18:00" };
            return result;
        }
        public static string[] AvailablePeriods(TimeSpan[] startTimes, int[] durations, TimeSpan beginWorkingTime, TimeSpan endWorkingTime, int consultationTime)
        {
            beginWorkingTime = TimeSpan.FromHours(8);
            endWorkingTime = TimeSpan.FromHours(12);
            consultationTime = 30;
            Console.WriteLine(beginWorkingTime);
            TimeSpan work = beginWorkingTime + TimeSpan.FromMinutes(consultationTime);
            Console.WriteLine(work);
            TimeSpan startTime = TimeSpan.FromHours(10);
            int duration = 90;
            TimeSpan diner = startTime + TimeSpan.FromMinutes(duration);
            int count = 1;

            while (work != endWorkingTime) {
                if (work == startTime) work = diner;
                else work += TimeSpan.FromMinutes(consultationTime);
                //Console.WriteLine (work);
                count+=1;
                }

            Console.WriteLine(count);

            TimeSpan[] startTimes = new TimeSpan[count];
            TimeSpan work1 = beginWorkingTime + TimeSpan.FromMinutes(consultationTime);
            startTimes[0] = work1;
            Console.WriteLine(startTimes[0]);
            for(int i =1; i<count; i++ ){
                if (work1 == startTime) work1 = diner;
                else work1 += TimeSpan.FromMinutes(consultationTime);
                startTimes[i] = work1;
                Console.WriteLine(startTimes[i]);
            }
        }
    }
}
