﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Uchet_Zayavok.Pages
{
    /// <summary>
    /// Логика взаимодействия для Avtorization.xaml
    /// </summary>
    public partial class Avtorization : Page
    {
        public Avtorization()
        {
            InitializeComponent();
        }

        private void BtnInLogin_Click(object sender, RoutedEventArgs e)
        {
            if (TxbLogin.Text == null && PsbPassword.Password == null)
            {
                MessageBox.Show("Такого пользователя нет!", "Ошибка при авторизации",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                try
                {
                    if (TxbLogin.Text == "Client")
                    {
                        Classes.manager.MainFrame.Navigate(new Client());
                    }
                    else if (TxbLogin.Text == "Ispolnitel")
                    {
                        Classes.manager.MainFrame.Navigate(new Ispolnitel());
                    }
                    else if (TxbLogin.Text == "Manager")
                    {
                        Classes.manager.MainFrame.Navigate(new Manager());
                    }
                    else
                    {
                        MessageBox.Show("Данные не обнаружены!", "Уведомление",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                    }                               
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message.ToString(), "Критическая работа приложения",
                            MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            
        }
    }
}
