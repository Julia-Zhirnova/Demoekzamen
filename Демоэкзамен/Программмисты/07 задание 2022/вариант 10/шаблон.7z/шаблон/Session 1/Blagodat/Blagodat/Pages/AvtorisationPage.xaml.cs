﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Blagodat.Pages
{
    /// <summary>
    /// Логика взаимодействия для AvtorisationPage.xaml
    /// </summary>
    public partial class AvtorisationPage : Page
    {
        public AvtorisationPage()
        {
            InitializeComponent();
        }

        private void BtnEntrance_Click(object sender, RoutedEventArgs e)
        {
            if (TBLogin.Text == String.Empty || PWBox.Password == String.Empty)
            {
                MessageBox.Show("Введите логин");
            }
            else if (TBLogin.Text == "Ivanov@namecomp.ru" && PWBox.Password == "2L6KZG")
            {
                this.NavigationService.Navigate(new Barcode());
            }
            else
            {
                MessageBox.Show("Вы ввели неправильны логин или пароль");
                this.NavigationService.Navigate(new Captcha());
            }
        }
    }
}
