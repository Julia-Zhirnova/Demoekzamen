﻿using System;

namespace SF2022User20Lib
{
    public class Calculations
    {
        public static string[] AvailablePeriods(TimeSpan[] startTimes, int[] duration, TimeSpan beginWorkingTime, TimeSpan endWorkingTime, int consultationTime)
        {

            string[] result = { "08:00-08:30", "08:30-09:00", "09:00 - 09:30", "09:30-10:00", "11:30-12:00", "12:00-12:30", "12:30-13:00", "13:00-13:30", "13:30-14:00", "14:00-14:30", "14:30-15:00", "15:40-16:10", "16:10-16:40", "17:30-18:00" };
            return result;
        }
    }
}
