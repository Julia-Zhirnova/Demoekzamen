using Microsoft.VisualStudio.TestTools.UnitTesting;
using SF2022User20Lib;
using System;

namespace TestProjectSF2022User20Lib
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void CheckIntervals()
        {
            TimeSpan beginWorkingTime = new TimeSpan(6, 07, 08, 00, 00);
            TimeSpan endWorkingTime = new TimeSpan(6, 07, 18, 00, 00);
            int consultationTime = 30;
            DateTime date1 = new DateTime(2022, 6, 07, 10, 00, 00);
            DateTime date2 = new DateTime(2022, 6, 07, 11, 00, 00);
            TimeSpan interval1 = date1.Subtract(date2);
            DateTime date3 = new DateTime(2022, 6, 07, 15, 00, 00);
            TimeSpan interval2 = date2.Subtract(date3);
            DateTime date4 = new DateTime(2022, 6, 07, 15, 30, 00);
            TimeSpan interval3 = date3.Subtract(date4);
            DateTime date5 = new DateTime(2022, 6, 07, 16, 50, 00);
            TimeSpan interval4 = date4.Subtract(date5);
            TimeSpan[] startTimes = new[] { interval1, interval2, interval3, interval4 };
            int[] durations = new[] { 60, 30, 10, 10, 40 };
            string[] actual = Calculations.AvailablePeriods(startTimes, durations, beginWorkingTime, endWorkingTime, consultationTime);
            string[] expected = { "08:00-08:30", "08:30-09:00", "09:00 - 09:30", "09:30-10:00", "11:30-12:00", "12:00-12:30", "12:30-13:00", "13:00-13:30", "13:30-14:00", "14:00-14:30", "14:30-15:00", "15:40-16:10", "16:10-16:40", "17:30-18:00" };
            Assert.ReferenceEquals(actual, expected);
        }
    }
}
