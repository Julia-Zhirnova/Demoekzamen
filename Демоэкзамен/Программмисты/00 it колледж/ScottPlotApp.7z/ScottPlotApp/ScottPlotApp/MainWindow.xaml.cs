﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ScottPlotApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //radar
            double[,] values = {
                { 78,  83, 84, 76, 43, 55 },
                { 100, 50, 70, 60, 90, 33 }
            };
            RadarPlot.Plot.AddRadar(values);
            RadarPlot.Plot.Frameless();
            RadarPlot.Plot.Grid(enable: false);
            RadarPlot.Refresh();
            //pie
            double[] valuesPie = { 778, 43, 283, 76, 184 };
            string[] labelsPie = { "C#", "JAVA", "Python", "F#", "PHP" };
            var pie = PiePlot.plt.AddPie(valuesPie);
            pie.SliceLabels = labelsPie;
            pie.ShowPercentages = true;
            pie.ShowValues = true;
            pie.ShowLabels = true;
            PiePlot.plt.Legend();
            PiePlot.Refresh();
            //line
            double[] valuesLine = new double[] { 1, 2, 3, 4, 5, 10, 9, 8, 7 };
            DateTime[] dates = new DateTime[] {DateTime.Now, 
                DateTime.Now.AddDays(2),
                DateTime.Now.AddDays(3),
                DateTime.Now.AddDays(4),
                DateTime.Now.AddDays(5),
                DateTime.Now.AddDays(6),
                DateTime.Now.AddDays(7),
                DateTime.Now.AddDays(8),
                DateTime.Now.AddDays(9),
            };
            double[] xs = dates.Select(x => x.ToOADate()).ToArray();
            LinePlot.Plot.AddScatter(xs, valuesLine);
            LinePlot.Plot.XAxis.DateTimeFormat(true);
            double[] yPositions = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            string[] yLabels = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };
            LinePlot.Plot.YAxis.ManualTickPositions(yPositions, yLabels);
            LinePlot.Refresh();
        }
    }
}
